import React from "react";
import "./Experince.css";

function Experience() {
  return <div>Experience</div>;
}

export default Experience;
