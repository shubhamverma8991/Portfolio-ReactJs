import React from "react";

function testimonial() {
  return <div>testimonial</div>;
}

export default testimonial;
