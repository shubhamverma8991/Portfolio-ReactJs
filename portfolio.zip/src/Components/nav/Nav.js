import React from "react";

function Nav() {
  return <div>Nav</div>;
}

export default Nav;
