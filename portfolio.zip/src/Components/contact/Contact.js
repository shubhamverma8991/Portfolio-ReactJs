import React from "react";
import "./Contact.css";

function Contact() {
  return <section id="contact">Contact</section>;
}

export default Contact;
