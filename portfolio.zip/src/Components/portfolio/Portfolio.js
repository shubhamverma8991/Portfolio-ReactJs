import React from "react";
import "./Portfolio.css";
function Portfolio() {
  return <div>Portfolio</div>;
}

export default Portfolio;
